const {MongoClient} = require('mongodb');

const Client = new MongoClient('mongodb+srv://rawatesudarshan5015:sudarshan@cluster0.0ue881o.mongodb.net/');

let database;
async function connectdb(){
    try{
        await Client.connect()
        database = Client.db('test');
        console.log('Database connected');
    }catch(err){
        console.log(err);
    }


}

async function getdb(){
    if(database){
        return database;
    }else{
        console.log('Database not found');
    }
}

module.exports = {
    connectdb,
    getdb
}