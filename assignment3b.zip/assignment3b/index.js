const express = require('express');
const {connectdb,getdb} = require('./mongodb.js');
const app = express();

app.use(express.json());

app.get('/users',async (req,res)=>{
   const db = await getdb();
   const users = await db.collection('users').find().toArray();
   res.send(users);
});

app.post('/users',async (req,res)=>{
    const body = req.body;
    const db = await getdb();
    const result=await db.collection('users').insertOne(body);
    res.send(result);
});

app.delete('/users/:name',async (req,res)=>{
    const name = req.params.name;
    const db = await getdb();
    const result = await db.collection('users').deleteOne({name:name});
    res.send(result);
});

app.patch('/users/:name',async(req,res)=>{
    const name = req.params.name;
    const body = req.body;
    const db = await getdb();
    const result = await db.collection('users').updateOne({name:name},{$set:body});
    res.send(result);
});

connectdb()
.then(()=>{
    app.listen(3000,()=>{
        console.log('server is running on port 3000');
    })
    
})

.catch(()=>{
    console.log("server not ready");
});